# Chá do Oli — convite interativo

Convite do Chá do Oli, preparado para GitHub Pages.

## Publicação

1. Crie um repositório público chamado **cha-do-oli**.
2. Envie `index.html`, `Cha_do_Oli_14_novembro.ics` e `.nojekyll` para a raiz da branch `main`.
3. Abra **Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save**.
4. Acesse `https://luornel.github.io/cha-do-oli/` após a publicação.

O convite exibe opções de presente e facilita pagamentos Pix. Não há reserva automática de cotas nem confirmação de pagamentos.
O Calendário Apple pode exigir importação manual do arquivo `.ics`.
